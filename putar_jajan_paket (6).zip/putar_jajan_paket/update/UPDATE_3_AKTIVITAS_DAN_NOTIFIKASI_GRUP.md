# UPDATE 3: Aktivitas grup, notifikasi, dan pengaturan notifikasi (Putar Jajan)

Status: aplikasi Putar Jajan sudah SELESAI dan berjalan penuh, dan UPDATE 2 sudah dipasang (grup, kode undangan, catatan grup, roda bersama, SyncState/SyncStrip/SyncBadge, event grup ditulis ke groups/{gid}/events). Tugas ini hanya MENAMBAH layar Aktivitas, notifikasi, dan pengaturan notifikasi di atasnya. Jangan membangun ulang atau menilai ulang layar yang sudah ada. Tema Kucing TIDAK dikerjakan di sini; pakai hanya tema yang aktif sekarang (Pasar Malam) lewat token yang sudah ada.

## 0. Aturan dan acuan
- Pelajari struktur kode secukupnya (repository grup, model event, SyncState, notifikasi lokal, router) hanya agar fitur tersambung; pakai ulang, jangan menduplikasi. Gaya mengikuti yang sudah ada (token tema, widget Sticker*, ikon custom, tanpa emoji, tanpa ikon bawaan).
- Acuan visual: design/screens 20 (20_grup_aktivitas_status.png), 21 (21_grup_notifikasi.png), 44 (44_grup_pengaturan_notifikasi.png) dan design/source Grup5, Grup6, Grup7 (sumber kebenaran angka persis). Katalog semua notifikasi: design/screens 46 (banner), 47 (sistem Android), 48 (dialog), 49 (aturan) dan design/source Notif1 sampai Notif4.
- Jika event belum ditulis dengan benar oleh UPDATE 2 (payload nominal, judul, sisa budget), laporkan di A0 dan perbaiki dulu sebelum lanjut.
- Mulai dengan A0 (tanpa kode, singkat) dan tunggu "lanjut".

## 1. Aktivitas grup (layar 20)
Jalur masuk: ikon lonceng (dengan jumlah belum dibaca) di top bar semua tab utama (Pilih permainan, Roda, Catatan, Riwayat, Roda bersama; hanya tampil jika pengguna ada di grup, memakai widget TopBarActions dari UPDATE 1B) -> Aktivitas; ikon roda gigi di header Aktivitas -> layar 44.
- Header: tombol kembali, judul "Aktivitas grup" (22px, satu baris), tombol roda gigi 46 bulat.
- Filter chip: Semua · N, Roda, Catatan (terpilih = Matahari dengan bayangan).
- Baris label: pill "BARU · N" di kiri dan tombol pill "Tandai dibaca" di kanan; bagian "SEBELUMNYA" berikutnya.
- Kartu aktivitas (bergaris 3, radius 22, bayangan; kartu baru bayangan lebih besar dan pill "Baru" di pojok kanan atas): avatar inisial berwarna dengan lencana jenis (struk untuk catatan, roda untuk putaran) di pojok kanan bawah; baris judul "<b>Nama</b> menambahkan pengeluaran" atau "<b>Nama</b> memutar roda"; sub judul (nama jajan atau "Budget baru untuk sesi ini"); deretan chip bergaris: nominal (Matahari untuk catatan, Lavender untuk putaran), "Sisa RpX" (Mint, hanya untuk catatan), dan waktu relatif dengan ikon jam ("2 mnt lalu", "Kemarin"). Aktivitas lama berbentuk kartu ringkas dengan chip waktu di kanan. Aktivitas member_join dan member_leave berbentuk ringkas. Aksi milik sendiri tampil sebagai "Kamu" dan TIDAK pernah berstatus Baru.
- Kartu bawah "Arti status sinkron" (widget SyncLegend): lima baris, tiap baris lingkaran ikon bergaris, label dalam pil bergaris lebar tetap, dan keterangan: Tersinkron (centang, Mint), Menunggu (jam, krim), Menyinkronkan (panah, Matahari, ikon berputar 1,2 detik linier), Offline (awan dicoret, ink, ikon putih), Gagal (segitiga, tomat). Ikon dan label sama dengan SyncBadge/SyncStrip yang sudah ada; satu sumber kebenaran, jangan duplikasi.
- Belum dibaca: event milik orang lain dengan createdAt > members/{uid}.lastReadAt. Kartu tetap berstatus Baru selama layar terbuka; lastReadAt diset saat layar ditutup atau tombol "Tandai dibaca" ditekan (ini keputusan UX agar pengguna sempat melihat mana yang baru). Jumlah di lonceng dan "BARU · N" memakai perhitungan yang sama.
- Teknis: stream event terbaru (30 pertama, muat lagi saat gulir), dikelompokkan Baru/Sebelumnya, waktu relatif diperbarui tiap menit, tampilan kosong ("Belum ada aktivitas"), loading (skeleton), dan error ramah. Offline: tampilkan event dari cache dan SyncStrip yang sudah ada.

## 2. Notifikasi dalam aplikasi dan sistem Android
Dua pengalaman berbeda; jangan dianggap selalu muncul bersamaan.
Dalam aplikasi (InAppBanner): hanya untuk aktivitas orang LAIN, mis. "Dina menambahkan Rp30.000 untuk sate. Sisa grup Rp170.000." Turun dari atas dengan mantul, bertahan 4 detik, hilang sendiri, maksimal satu tampil; event beruntun dalam 3 detik digabung jadi satu. Untuk aksi sendiri cukup snackbar konfirmasi singkat. Tidak ada dialog untuk aktivitas kecil.
Sistem Android (flutter_local_notifications; aturan notifikasi lokal yang sudah ada tetap berlaku): HP pelaku TIDAK menerima notifikasi sistem untuk aksinya sendiri; HP anggota lain menerima kalimat lengkap: "Dina menambahkan pengeluaran Rp30.000 untuk sate taichan. Sisa budget grup sekarang Rp170.000." Beberapa aktivitas dalam 60 detik digabung dengan memperbarui satu notifikasi (id tetap per grup): "3 aktivitas baru di Date Jumat". Channel khusus "Aktivitas grup" (importance default, tanpa heads-up mengganggu). Ketuk notifikasi membuka layar Aktivitas grup tersebut, termasuk dari cold start (getNotificationAppLaunchDetails). Ikon kecil putih polos, accent tomat. Referensi tampilan: layar 21 (HP A: konfirmasi singkat; HP B: kalimat lengkap dan ringkasan).
Batasan jujur: tanpa FCM, notifikasi dari anggota lain hanya muncul selama aplikasi masih hidup (latar atau depan). Catat ini di README.

## 2b. Katalog notifikasi lengkap (layar 46 sampai 49)
Satu pemetaan tipe event -> tampilan, dipakai di banner (46), sistem (47), dialog (48), dan feed (20). Teks persis seperti di desain (nama, nominal, dan angka diganti data nyata). Aturan umum: pelaku tidak menerima banner atau notifikasi sistem untuk aksinya sendiri; grup dibisukan menekan banner dan sistem tetapi feed dan penanda belum dibaca tetap jalan; pada data offline, kalimat memakai nilai terbaru yang diketahui perangkat.
- expense: banner "Dina menambahkan Rp30.000" / "Sate taichan · Sisa grup Rp170.000"; sistem "Dina menambahkan pengeluaran Rp30.000 untuk sate taichan. Sisa budget grup sekarang Rp170.000." dengan aksi "Catat jajan" dan "Lihat sisa"; sakelar Catatan.
- expense_deleted: banner "Dina menghapus sebuah catatan" / "Es teh jumbo Rp12.000 · Sisa grup Rp182.000"; tanpa notifikasi sistem; sakelar Catatan.
- spin: banner "Raka memutar roda: Rp200.000" / "Budget baru untuk sesi ini"; sistem "Raka memutar roda dan mendapat Rp200.000 untuk sesi ini."; sakelar Roda.
- budget 80% (dihitung lokal, satu kali per sesi): banner "Sisa Rp40.000 lagi" / "80% terpakai dari Rp200.000"; sistem "Sisa budget grup tinggal Rp40.000 (80% terpakai)."; sakelar Budget.
- budget lewat (dihitung lokal, satu kali per sesi saat melewati 100%): banner "Budget lewat Rp12.000" / "Total Rp212.000 dari Rp200.000"; sistem "Budget grup lewat Rp12.000. Total Rp212.000 dari Rp200.000."; sakelar Budget.
- session_end: banner "Date selesai: Lolos!" (atau "Lewat") / "Hemat Rp25.000 · 5 jajan"; sistem "Date grup selesai: Lolos! Hemat Rp25.000."; sakelar Hasil date.
- member_join: banner "Bima bergabung" / "Sekarang 4 anggota di Date Jumat"; sistem "Bima bergabung ke grup. Sekarang ada 4 anggota."; sakelar Anggota (default mati, di feed selalu ada).
- member_leave: banner "Bima keluar dari grup" / "Tinggal 3 anggota"; sakelar Anggota.
- budget_changed (pemilik mengubah mode atau nominal): banner "Pemilik mengubah budget grup" / "Date berikutnya: Rp250.000"; feed; tanpa notifikasi sistem; tanpa sakelar (selalu); gaya ikon seperti code_changed.
- session_start (mode Angka tetap): banner "Date baru dimulai" / "Budget Rp200.000"; sakelar Hasil date.
- code_changed: banner "Kode undangan diganti" / "Kode lama tidak berlaku lagi"; hanya banner dan feed; tanpa sakelar (selalu).
- member_removed (untuk yang dikeluarkan): notifikasi sistem berlabel "Penting" "Kamu dikeluarkan dari grup Date Jumat." dan dialog saat aplikasi dibuka; untuk anggota lain hanya baris feed "Pemilik mengeluarkan Bima".
- group_deleted: notifikasi sistem Penting dan dialog "Grup sudah dihapus" ("Pemilik menghapus Date Jumat. Catatan grup tidak bisa dibuka lagi."); grup hilang dari daftar setelah "Mengerti".
- sync_failed: strip status yang sudah ada + notifikasi sistem Penting "2 catatan belum terkirim. Tersimpan aman di HP ini." dengan aksi "Coba lagi" + dialog "2 perubahan belum terkirim" dengan tombol "Nanti saja" dan "Coba lagi"; coba otomatis ulang dengan backoff; kembali tersinkron tidak memunculkan notifikasi (cukup strip menghilang).
- Dialog konfirmasi pemilik (layar 48): "Keluarkan Bima?" / "Bima tidak bisa lagi melihat catatan grup. Catatan yang sudah ia buat tetap ada." Tombol "Batal" dan "Keluarkan".
- Dialog hanya untuk: dikeluarkan, grup dihapus, gagal sinkron, konfirmasi pemilik. Jangan menambah dialog untuk aktivitas biasa.
- Banner: satu tampil sekaligus; beberapa kejadian dalam 3 detik digabung ("3 aktivitas baru"); ikon bulat berwarna per jenis (kuning pengeluaran dan peringatan 80%, krim dihapus dan keluar, lavender roda, tomat bahaya, mint bergabung dan selesai, biru kode); semua ikon digambar custom.
- Notifikasi sistem: judul = nama grup (untuk yang bersifat pribadi: "Putar Jajan"), kartu berlabel "Penting" tidak bisa dimatikan, dikelompokkan per grup dengan ringkasan setelah 60 detik.

## 2c. Animasi, haptic, dan gerak (WAJIB; sumber angka persis: @keyframes di design/source Notif1, Notif2, Notif3, Grup3, Grup5)
Semua animasi memakai AnimationController dan CurvedAnimation, tanpa paket animasi pihak ketiga. easeOutBack = cubic-bezier(.2,1.2,.3,1).
- InAppBanner: masuk dengan translateY dari -80 ke posisi (melewati +5 lalu mengendap) dan opacity 0 ke 1 selama 450ms easeOutBack; ikon bulat berskala 0,5 ke 1,18 ke 1 selama 350ms, tertunda 150ms; tahan 4000ms (dijeda selama jari menahan banner); keluar translateY -44 dan fade selama 250ms easeIn. Geser ke atas menutup lebih cepat; ketuk membuka layar Aktivitas dan menutup banner. Banner baru saat banner lama masih tampil: banner lama keluar 150ms, kontennya digabung ("3 aktivitas baru") dengan angka berganti crossfade 200ms dan banner membal kecil (skala 1 ke 1,04 ke 1). Hanya satu banner sekaligus (antrean maksimal 1).
- Dialog penting: scrim ink opasitas 0 ke 0,45 selama 200ms; kartu skala 0,8 ke 1,04 ke 1 plus fade selama 320ms easeOutBack; ikon peringatan (gagal sinkron, budget lewat) bergoyang rotasi -9, 9, -6 derajat total 400ms setelah 200ms; keluar skala 0,96 dan fade 160ms. Tombol memakai efek tekan Sticker yang sudah ada.
- Lonceng di Roda bersama: saat ada aktivitas baru dari orang lain, lonceng bergoyang (rotasi -16, 14, -10, 7, 0 derajat, titik putar di atas, total 600ms); angka belum dibaca muncul dengan skala 0 ke 1,35 ke 1 selama 250ms, dan saat angka berubah ia berdenyut sekali.
- Feed Aktivitas (layar 20): kartu baru masuk dari atas (translateY -16 ke 0 plus fade, 350ms, jeda 80ms per kartu); pill "Baru" berdenyut dua kali (skala 1 ke 1,14 ke 1 ke 1,08 ke 1, 600ms) satu kali saat layar dibuka; "Tandai dibaca": pill Baru fade 200ms dan bayangan kartu mengecil dari besar ke kecil 200ms; kartu baru yang datang saat layar terbuka masuk dari atas dan menggeser daftar dengan AnimatedList.
- SyncStrip dan SyncLegend: strip muncul (fade + geser 8, 250ms) setelah debounce 1,5 detik dan hilang fade 300ms; ikon Menyinkronkan berputar 1,2 detik linier selama status aktif.
- Pengaturan (layar 44): knob sakelar bergeser 180ms easeOut sambil warna trek crossfade; chip durasi bisu terpilih membal (skala 1 ke 1,06 ke 1, 180ms); saat grup dibisukan, sakelar jenis meredup (opacity 1 ke 0,45, 200ms) dan teks "Dibisukan sampai HH.MM" masuk fade + geser 6.
- Notifikasi sistem Android: animasinya diatur oleh sistem Android dan TIDAK bisa dikustomisasi. Yang bisa diatur hanya importance, ikon kecil, warna aksen, dan pengelompokan; jangan mencoba membuat animasi sendiri di sana. Katakan ini di README.
- Haptic: banner muncul = HapticFeedback.lightImpact (hanya jika Getar menyala dan aplikasi di depan); budget 80% = lightImpact; budget lewat = mediumImpact; dialog penting muncul = mediumImpact; sakelar = selectionClick; chip durasi = selectionClick. Tidak ada haptic untuk aksi sendiri.
- Suara: banner dan dialog tidak menambah suara baru; boleh memakai SoundService yang sudah ada (notif_warning untuk budget 80% dan lewat) hanya jika Suara menyala dan aplikasi di depan.
- Gerak berkurang: jika MediaQuery.disableAnimations atau pengaturan Android "Hapus animasi" aktif, semua gerakan di atas diganti fade 100ms tanpa mantul, tanpa goyang, tanpa denyut; haptic tetap mengikuti pengaturan Getar.
- Kinerja: banner dan dialog dibangun sebagai Overlay terpisah dengan RepaintBoundary; tidak ada rebuild layar di bawahnya saat animasi berjalan; uji di profile mode tanpa jank pada perangkat kelas menengah.

## 3. Pengaturan notifikasi grup (layar 44)
Jalur masuk: roda gigi di header Aktivitas, dan baris "Notifikasi" di layar Kelola grup (bila sudah ada). Disimpan lokal per grup (database lokal).
- Sakelar "Bisukan grup" dengan chip durasi 1 jam, 8 jam, Sampai kunyalakan. Simpan muteUntil (null = tidak bisu, nilai sangat jauh = sampai dinyalakan). Saat dibisukan: tulis "Dibisukan sampai HH.MM" (atau "sampai kunyalakan"), semua sakelar jenis tampil redup dan tidak bisa diubah, banner dalam aplikasi dan notifikasi sistem tidak tampil. Penanda belum dibaca dan jumlah di lonceng TETAP berjalan. Saat bisu berakhir: tidak ada notifikasi susulan; aplikasi hanya kembali normal.
- Lima sakelar jenis: Catatan pengeluaran (mencakup expense dan expense_deleted), Hasil putaran roda, Peringatan budget (80% dan lewat), Hasil date selesai (semua default menyala), Anggota masuk atau keluar (default mati). Di bawahnya catatan "Selalu tampil: dikeluarkan dari grup, grup dihapus, gagal sinkron" (tidak bisa dimatikan). Jenis yang mati tidak memunculkan banner maupun notifikasi sistem, tetapi tetap tercatat di feed.
- Kartu "Suara dan getar": penjelasan dan tombol "Buka pengaturan Android" (buka pengaturan channel "Aktivitas grup" lewat intent pengaturan notifikasi aplikasi atau channel; perlu kode native kecil via MethodChannel). Jelaskan: jika channel dimatikan di Android, sakelar di aplikasi tidak berpengaruh.
- Catatan kaki: aktivitas dalam 1 menit digabung jadi satu notifikasi; kamu tidak menerima notifikasi untuk aksimu sendiri.
- Pengaturan "Peringatan budget 80%": dihitung lokal dari sisa budget turunan; kirim satu kali per sesi saat melewati 80%, bukan berulang.

## 4. Komponen baru
ActivityCard (baru dan ringkas), SectionPill, FilterChips, SyncLegend, InAppBanner, SettingToggle (sakelar 48x30 berborder ink, tombol dalam putih atau ink), MuteChips, NotificationSettingsPage, ikon roda gigi dan lonceng custom (CustomPainter/Path, stroke 2,8 round). Gunakan ulang avatar, chip, kartu, dan ikon status yang sudah ada.

## 5. FCM (opsional, tahap terpisah)
Cloud Function onCreate pada events mengirim pesan data-only ke topic per jenis (group_{gid}_{jenis}) dengan actorUid; klien mengabaikan jika actorUid == uid sendiri lalu membangun notifikasi lokal dengan aturan penggabungan bagian 2. Sakelar jenis dan bisukan mengatur langganan topic. Notifikasi saat aplikasi ditutup baru berfungsi dengan ini, dan butuh paket Firebase Blaze. Jelaskan biaya dan cara deploy dan tunggu persetujuan sebelum mengerjakannya.

## 6. Tahapan (berhenti di tiap tahap, tunggu "lanjut")
- A0: ringkas struktur kode relevan, cek event dari UPDATE 2, rencana per file. Tanpa kode.
- A1: model pengaturan per grup (muteUntil, jenis), logika bisu, perhitungan belum dibaca, pemetaan event ke teks; unit test.
- A2: layar Aktivitas (20) + SyncLegend + lastReadAt.
- A3: lonceng di layar 18 + InAppBanner.
- A4: notifikasi sistem lokal, channel, penggabungan 60 detik, routing ketuk.
- A5: layar Pengaturan notifikasi (44) + intent pengaturan Android + polish.
- A6 (opsional): FCM + Cloud Functions.
Setelah tiap tahap: flutter analyze, flutter test, screenshot emulator dibanding design/screens, perbaiki selisih.

## 7. Pengujian dan kriteria selesai
Unit test: logika bisu (belum, aktif, berakhir, sampai kunyalakan), perhitungan belum dibaca (aksi sendiri tidak dihitung, lastReadAt), pemetaan jenis event ke sakelar, penggabungan notifikasi 60 detik, pemetaan event ke teks kalimat. Widget test animasi (banner masuk lalu hilang setelah 4 detik, antrean maksimal 1, banner digabung, mode gerak berkurang tanpa mantul, jeda saat ditahan), golden test layar 20 dan 44 pada lebar 320 dan 390dp dan textScale 1.3 tanpa overflow. Uji manual dua HP: A mencatat, B menerima banner dan notifikasi (A tidak); B membisukan lalu A mencatat (B tidak menerima, tetapi lonceng bertambah); ketuk notifikasi dari kondisi app tertutup membuka Aktivitas. TalkBack: kartu aktivitas dibacakan lengkap (siapa, apa, jumlah, kapan, baru atau tidak); status tidak hanya dibedakan warna. Selesai bila layar 20 dan 44 sesuai desain, semua banner, notifikasi sistem, dan dialog pada layar 46 sampai 48 tampil dengan teks dan aturan di bagian 2b, aturan layar 49 berlaku, layar dan fitur lama tidak berubah, tidak ada emoji atau ikon bawaan, flutter analyze bersih, dan keterbatasan tanpa FCM tercatat di README.
